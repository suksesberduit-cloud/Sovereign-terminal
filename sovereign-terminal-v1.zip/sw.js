const CACHE_NAME = 'sovereign-terminal-v1';
const ASSETS = [
  '/index.html',
  '/manifest.json',
  'https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@300;400;500&family=DM+Sans:wght@300;400;500&display=swap'
];

// Semua domain data/berita live — TIDAK PERNAH di-cache, selalu network,
// supaya harga/berita/kalender selalu fresh (baik punya SOVEREIGN
// maupun TERMINAL yang sekarang jadi satu tab di app ini).
const NETWORK_ONLY_MATCHERS = [
  'api.',                // allorigins, codetabs, coingecko, rss2json, dst
  'query1.finance',
  'query2.finance',
  'finance.yahoo.com',
  'corsproxy.io',
  'thingproxy.freeboard.io',
  'gold-api.com',
  'nfs.faireconomy.media',
  'congressinfor-production.up.railway.app',
  'senatestockwatcher.com',
  'house-stock-watcher-data.s3',
  'senate-stock-watcher-data.s3',
  'efdsearch.senate.gov',
  'www.sec.gov',
  'xoomar.com',
  'trmnl-worker.sukses-berduit.workers.dev',
  'news.google.com',
  'feeds.feedburner.com',
  'cointelegraph.com',
  'coindesk.com',
  'techcrunch.com',
  'theverge.com',
  'cnbcindonesia.com',
  'finance.detik.com'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(['/index.html', '/manifest.json']);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  const url = e.request.url;

  // Data/berita live — network only, tidak pernah cache
  if (NETWORK_ONLY_MATCHERS.some(m => url.includes(m))) {
    e.respondWith(
      fetch(e.request).catch(() => new Response('{"error":"offline"}', { headers: { 'Content-Type': 'application/json' } }))
    );
    return;
  }

  // App shell — cache first, fallback ke network
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(response => {
      if (response.ok) {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(e.request, clone));
      }
      return response;
    }))
  );
});
